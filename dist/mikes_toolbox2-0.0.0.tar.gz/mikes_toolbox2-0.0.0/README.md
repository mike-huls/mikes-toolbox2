# Mike's toolbox 2
This package is the result of a demonstration from an article that details how to create a package and publish it to pypi.org.
There is no useful conde contained in this package.

Check out the article [here](mikehuls.com/articles?tags=pypi) 