# Mike's toolbox 2
This package is the result of an article that demonstrates how to create a package and publish it in a few easy steps.
There is no useful code contained in this package.

Usefull links:  
- Find the article [here](mikehuls.com) or [here](https://mikehuls.medium.com/creating-and-publishing-your-own-python-package-for-absolute-beginners-7656c893f387)   
- Find the source code for creating the package on [Github](https://github.com/mike-huls/mikes-toolbox2)

Read more / connect:
- [Personal website](https://mikehuls.com)
- [Medium profile](https://mikehuls.medium.com)
- [![Twitter URL](https://img.shields.io/twitter/url/https/twitter.com/Mike_Huls.svg?style=social&label=Follow%20Mike_Huls)](https://twitter.com/Mike_Huls)
